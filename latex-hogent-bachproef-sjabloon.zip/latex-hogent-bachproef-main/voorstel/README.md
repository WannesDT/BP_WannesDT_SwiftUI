# LaTeX-sjabloon het bachelorproefvoorstel

Deze directory bevat het sjabloon voor je onderzoeksvoorstel. Het is gebaseerd op de documentclass [hogent-article](https://github.com/HoGentTIN/latex-hogent-article).

**LET OP, DOE DIT EERST!** Hernoem het .tex-bestand `voorbeeld-bpvoorstel.tex` met je eigen naam: `FamilienaamVoornaam-bpvoorstel.tex`